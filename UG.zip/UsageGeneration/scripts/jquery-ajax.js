

$(function() {
    $(".usage").keyup(usagefunction);
	});

function usagefunction() {
	var $th = $(this);
	$th.val( $th.val().replace(/[^0-9.]/g, function(str) { alert('You typed " ' + str + ' ".\n\nPlease use only integer or float values');
	return '';
	} ) );
	}


$(function() {
    $(".svccode").keyup(svccodefunction);
	});

function svccodefunction() {
	var $th = $(this);
	$th.val( $th.val().replace(/[^0-9a-zA-Z]/g, function(str) { alert('You typed " ' + str + ' ".\n\nPlease use only letters or numbers');
	return '';
	} ) );
	}


$(function() {
    $(".mac").focusout(macfunction);
	});

function macfunction() {
	var $th = $(this);
	$th.val( $th.val().replace(/[^0-9a-zA-Z.]/g, function(str) { alert('You typed " ' + str + ' ".\n\nPlease use only letters or numbers or .');
	//$th.val( $th.val().replace(/[0-9a-zA-Z]{4}\.[0-9a-zA-Z]{4}\.[0-9a-zA-Z]{4}/g, function(str) { alert('You typed " ' + str + ' ".\n\nPlease use only letters or numbers.');
	return '';
	} ) );
	}


$(function() {
    $(".usage").focusout(usagemaxfunction);
	});

function usagemaxfunction() {
	var $th = $(this);
	//alert($th.val());
	if($th.val() > 300)
		{
		alert("The usage should be lesser than or equal to 300 Gigs");
		$th.val("0.0");
		
		}
	
	
	return '';
	}





function testfunction() {
	var $th = $(this);
	$th.val( $th.val().replace(/[^0-9a-zA-Z.]/g, function(str) { alert('You typed " ' + str + ' ".\n\nPlease use only letters or numbers or .');
	//$th.val( $th.val().replace(/[0-9a-zA-Z]{4}\.[0-9a-zA-Z]{4}\.[0-9a-zA-Z]{4}/g, function(str) { alert('You typed " ' + str + ' ".\n\nPlease use only letters or numbers.');
	return '';
	} ) );
	}




$(document).ready(function() {
        $('.mac').focusout(function() {
        	var $th = $(this);
        	if($th.val() === "")
        	{
        		
        	}
        		
        		else
        	{
        	
        	
        	var zippy = $(this).val();

        $.post('response.jsp', { zipcode: zippy }, function(data) {
            
        	var x = data;
        	if(x < 1)
        		{
        			alert("Please provide a correct mac address");
        			$th.val("");
        			
        		}	
        	
        		
        	
        });   }
    });
    
});







